import cv2
import pickle
import numpy as np
from datetime import datetime
import pyttsx3
import time
import os
import csv
import speech_recognition as sr
from utils.db_3utils import log_attendance, log_permission
from insightface.app import FaceAnalysis
from scipy.spatial.distance import cosine

app = FaceAnalysis(name='buffalo_sc', providers=['CPUExecutionProvider'])
app.prepare(ctx_id=0)

with open("embeddings/embeddings.pkl", "rb") as f:
    known_faces = pickle.load(f)

engine = pyttsx3.init()
recognizer = sr.Recognizer()

seen_ids = {}
entry_logged = {}
lunch_status = {}
break_status = {}
permission_logged = set()

def say(text):
    engine.say(text)
    engine.runAndWait()

def capture_audio_reason():
    with sr.Microphone() as source:
        say("Please state your reason.")
        print("Listening for permission reason...")
        audio = recognizer.listen(source, timeout=5)
        try:
            reason = recognizer.recognize_google(audio)
            print("Recognized reason:", reason)
            return reason
        except sr.UnknownValueError:
            return "Could not understand"
        except sr.RequestError:
            return "Speech service error"

def is_permission_time(hour, minute):
    return (hour == 11 or (hour == 12 and minute <= 55)) or \
           (hour == 14 or (hour == 15 or (hour == 16 and minute <= 20))) or \
           (hour >= 17 and hour <= 20)

def recognize():
    cap = cv2.VideoCapture(0)

    while True:
        ret, frame = cap.read()
        if not ret or frame is None:
            break

        faces = app.get(frame)

        for face in faces:
            emb = face['embedding']
            matched = False
            x1, y1, x2, y2 = map(int, face['bbox'])

            for data in known_faces:
                dist = cosine(emb, data['embedding'])
                if dist < 0.45:
                    emp_id, name = data['id'], data['name']
                    now = datetime.now()
                    time_str = now.strftime("%I:%M %p")
                    hour, minute = now.hour, now.minute

                   
                    if emp_id not in seen_ids:
                        seen_ids[emp_id] = now
                        entry_time = time_str

                        if hour < 9 or (hour == 9 and minute == 10):
                            status, late = "Present", "No"
                            say(f"{name}, Good morning. Marked present at {time_str}")
                        else:
                            status, late = "Present", "Yes"
                            delay = (hour - 9) * 60 + minute
                            say(f"{name}, you are late by {delay} minutes")
                        
                        log_attendance(emp_id, name, status, entry_time, "", late)
                        entry_logged[emp_id] = True

                    else:
                        
                        if is_permission_time(hour, minute) and emp_id not in permission_logged:
                            say(f"{name}, you're leaving during permission hours.")
                            reason = capture_audio_reason()
                            say("Permission recorded.")
                            log_permission(emp_id, name, reason, time_str)
                            permission_logged.add(emp_id)

                        
                        if hour == 13 and emp_id not in lunch_status:
                            lunch_status[emp_id] = {'out': time_str, 'in': None}
                            say(f"{name} left for lunch at {time_str}")

                        elif hour == 14 and emp_id in lunch_status and lunch_status[emp_id]['in'] is None:
                            lunch_status[emp_id]['in'] = time_str
                            say(f"{name} returned from lunch at {time_str}")

                        
                        if hour == 16 and minute >= 30 and emp_id not in break_status:
                            break_status[emp_id] = {'out': time_str, 'in': None}
                            say(f"{name} went for break at {time_str}")

                        elif hour == 17 and emp_id in break_status and break_status[emp_id]['in'] is None:
                            break_status[emp_id]['in'] = time_str
                            say(f"{name} returned from break at {time_str}")

                    
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.putText(frame, f"{name}", (x1, y1 - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                    matched = True
                    break

            if not matched:
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 2)
                cv2.putText(frame, "Unknown", (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

        cv2.imshow("Face Attendance", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break


    for emp_id, entry_time in seen_ids.items():
        exit_time = datetime.now().strftime("%I:%M %p")
        name = next((d['name'] for d in known_faces if d['id'] == emp_id), "")
        log_attendance(emp_id, name, "Present", entry_time.strftime("%I:%M %p"), exit_time, "")

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    recognize()
