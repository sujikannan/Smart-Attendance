import streamlit as st
import sqlite3
import pandas as pd
from datetime import date
import base64
from utils.db_utils import export_attendance


def check_password():
    def password_entered():
        if st.session_state["password"] == "admin123":
            st.session_state["password_correct"] = True
        else:
            st.session_state["password_correct"] = False

    if "password_correct" not in st.session_state:
        st.text_input("Enter admin password", type="password", on_change=password_entered, key="password")
        return False
    elif not st.session_state["password_correct"]:
        st.text_input("Enter admin password", type="password", on_change=password_entered, key="password")
        st.error("Incorrect password")
        return False
    else:
        return True

if not check_password():
    st.stop()


st.set_page_config(page_title="Face Attendance Dashboard", layout="wide")
st.title("🧑‍💼 Face Recognition Attendance Dashboard")


conn = sqlite3.connect("database.db")
c = conn.cursor()


st.markdown("###Export Attendance")
if st.button(" Export to Excel"):
    export_attendance()
    st.success("Exported to attendance_log.xlsx")


logs = pd.read_sql_query("SELECT * FROM attendance", conn)
logs.columns = logs.columns.str.lower()  


if 'date' in logs.columns:
    logs['date'] = pd.to_datetime(logs['date'], errors='coerce')
else:
    st.error("'date' column not found in attendance table.")
    st.stop()

st.subheader("Attendance Logs")
col1, col2 = st.columns(2)
with col1:
    start_date = st.date_input("From", value=date.today())
with col2:
    end_date = st.date_input("To", value=date.today())

filtered_logs = logs[
    (logs['date'] >= pd.to_datetime(start_date)) &
    (logs['date'] <= pd.to_datetime(end_date))
]

st.dataframe(filtered_logs, use_container_width=True)


def download_file(df, filename, filetype='csv'):
    if filetype == 'csv':
        csv = df.to_csv(index=False)
        b64 = base64.b64encode(csv.encode()).decode()
        href = f'<a href="data:file/csv;base64,{b64}" download="{filename}">Download CSV</a>'
    else:
        excel_buffer = pd.ExcelWriter(filename, engine='xlsxwriter')
        df.to_excel(excel_buffer, index=False, sheet_name='Attendance')
        excel_buffer.close()
        with open(filename, 'rb') as f:
            b64 = base64.b64encode(f.read()).decode()
        href = f'<a href="data:application/octet-stream;base64,{b64}" download="{filename}">Download Excel</a>'
    return href

st.markdown(download_file(filtered_logs, "filtered_attendance.csv"), unsafe_allow_html=True)

st.subheader("Registered Employees")

search_term = st.text_input("Search by Name or ID")
emp = pd.read_sql_query("SELECT * FROM employees", conn)
emp.columns = emp.columns.str.lower()

if search_term:
    emp = emp[emp['name'].str.contains(search_term, case=False, na=False) |
              emp['id'].astype(str).str.contains(search_term)]

st.dataframe(emp, use_container_width=True)


conn.close()
