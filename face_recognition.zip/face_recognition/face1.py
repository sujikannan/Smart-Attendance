import cv2
import os
import uuid
import pickle
import sqlite3
from insightface.app import FaceAnalysis
from utils.db_utils import insert_employee

# Initialize face analysis
app = FaceAnalysis(name='buffalo_sc', providers=['CPUExecutionProvider'])
app.prepare(ctx_id=0)

def capture_and_register():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Failed to open camera.")
        return

    print("Camera started. Scanning for face...")

    while True:
        ret, frame = cap.read()
        if not ret or frame is None:
            print("Camera error or frame not found.")
            break

        faces = app.get(frame)
        if faces:
            face = faces[0]
            emb = face['embedding']

            # === Get Manual Details ===
            emp_id = input("Enter Employee ID (manual): ")
            name = input("Enter Name: ")
            role = input("Enter Role: ")

            # === Save image ===
            os.makedirs("images", exist_ok=True)
            os.makedirs("embeddings", exist_ok=True)
            img_path = f"images/{emp_id}.jpg"
            cv2.imwrite(img_path, frame)

            # === Save embedding ===
            data = {'id': emp_id, 'name': name, 'role': role, 'embedding': emb}
            if os.path.exists("embeddings/embeddings.pkl"):
                with open("embeddings/embeddings.pkl", "rb") as f:
                    db = pickle.load(f)
            else:
                db = []

            db.append(data)
            with open("embeddings/embeddings.pkl", "wb") as f:
                pickle.dump(db, f)

            # === Insert into employee table ===
            insert_employee(emp_id, name, role, img_path)
            print(f"✅ Registered {name} with ID {emp_id}")
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    capture_and_register()


