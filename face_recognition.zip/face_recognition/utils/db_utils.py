# utils/db_utils.py
import sqlite3
import os
from openpyxl import Workbook

conn = sqlite3.connect("database.db")
c = conn.cursor()

c.execute('''CREATE TABLE IF NOT EXISTS employees (
    id TEXT PRIMARY KEY,
    name TEXT,
    role TEXT,
    img_path TEXT
)''')

c.execute('''CREATE TABLE IF NOT EXISTS attendance (
    emp_id TEXT,
    name TEXT,
    status TEXT,
    time TEXT
)''')
conn.commit()

def insert_employee(emp_id, name, role, img_path):
    c.execute("INSERT INTO employees VALUES (?, ?, ?, ?)", (emp_id, name, role, img_path))
    conn.commit()

def log_attendance(emp_id, name, status, time):
    c.execute("INSERT INTO attendance VALUES (?, ?, ?, ?)", (emp_id, name, status, time))
    conn.commit()

def export_attendance():
    c.execute("SELECT * FROM attendance")
    rows = c.fetchall()

    wb = Workbook()
    ws = wb.active
    ws.append(["Emp ID", "Name", "Status", "Time"])
    for row in rows:
        ws.append(row)
    wb.save("attendance_log.xlsx")
