import os
import csv
from datetime import datetime

def log_attendance(emp_id, name, status, entry_time, exit_time, late):
    file_path = "logs/attendance.csv"
    os.makedirs(os.path.dirname(file_path), exist_ok=True)

    today = datetime.now().strftime("%Y-%m-%d")

    file_exists = os.path.isfile(file_path)
    with open(file_path, 'a', newline='') as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(["Date", "Employee ID", "Name", "Status", "Entry Time", "Exit Time", "Late"])
        writer.writerow([today, emp_id, name, status, entry_time, exit_time, late])

def log_permission(emp_id, name, reason, time):
    file_path = "logs/permission_log.csv"
    os.makedirs(os.path.dirname(file_path), exist_ok=True)

    file_exists = os.path.isfile(file_path)
    with open(file_path, 'a', newline='') as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(["Date", "Employee ID", "Name", "Time", "Reason"])
        today = datetime.now().strftime("%Y-%m-%d")
        writer.writerow([today, emp_id, name, time, reason])
