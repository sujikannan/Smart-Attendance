import pandas as pd

df = pd.read_csv("logs/attendance.csv")
summary = df.groupby("Name").agg(
    Total_Present=('Status', lambda x: (x == 'Present').sum()),
    Total_Late=('Late', lambda x: (x == 'Yes').sum()),
    Days_Logged=('Date', 'nunique')
).reset_index()

summary['Absent_Days'] = 30 - summary['Days_Logged']
summary.drop(columns=['Days_Logged'], inplace=True)
summary.to_csv("logs/monthly_summary.csv", index=False)
